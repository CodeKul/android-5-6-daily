package com.example.sqlite

class MyDb : RoomData {
}