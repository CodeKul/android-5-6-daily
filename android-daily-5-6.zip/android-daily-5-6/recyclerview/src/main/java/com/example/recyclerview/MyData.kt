package com.example.recyclerview

data class MyData(
        val imgId : Int,
        val txt : String
)