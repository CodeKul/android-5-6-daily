package com.codekul.androddaily;

public class Car {

    public void start() {

    }
}
