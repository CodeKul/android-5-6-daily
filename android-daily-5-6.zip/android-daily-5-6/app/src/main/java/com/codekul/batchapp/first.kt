package com.codekul.batchapp

import com.melayer.malib.Car

var dt = "android"
val pi = 3.14
val num: Int = 65

fun showDt() {
    dt = "kotlin"
//    pi = 89
    println(dt)
}

fun whatsNum(): Int {
    val cr = Car()
    return 56
}

fun add(num1: Int, num2: Int): Int {
    return num1 + num2
}