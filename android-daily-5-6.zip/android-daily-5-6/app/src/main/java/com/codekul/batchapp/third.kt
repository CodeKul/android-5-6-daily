package com.codekul.batchapp

fun main(args: Array<String>) {
    var str : Any = "kotlin codekul"
    str = 45

    val obj = object {
        var nm = "android"
        var fn = fun() {

        }
    }
    obj.nm = "kotlin"
}